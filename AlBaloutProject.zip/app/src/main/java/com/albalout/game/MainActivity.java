package com.albalout.game;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import android.graphics.Color;

public class MainActivity extends Activity {
    int[] scores = new int[4];
    int target = 1000;
    boolean individual = false;
    TextView status;
    LinearLayout root;

    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }
    TextView text(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.rgb(35,35,35)); t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8),dp(8),dp(8),dp(8)); return t;
    }
    Button btn(String s) { Button b = new Button(this); b.setText(s); return b; }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }
    void shell(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18),dp(18),dp(18),dp(18));
        root.setBackgroundColor(Color.rgb(247,244,235));
        setContentView(root);
        TextView h=text(title,28); h.setTypeface(null,Typeface.BOLD);
        h.setTextColor(Color.rgb(20,95,65)); root.addView(h);
    }
    void showHome() {
        shell("البلوط");
        root.addView(text("لعبة الورق – نسخة أولية",18));
        Button team=btn("اللعب فريقين"); root.addView(team);
        Button solo=btn("اللعب أربعة كل واحد بوحدو"); root.addView(solo);
        Button targetBtn=btn("تغيير الهدف: "+target); root.addView(targetBtn);
        targetBtn.setOnClickListener(v->{target=target==1000?2000:1000; targetBtn.setText("تغيير الهدف: "+target);});
        team.setOnClickListener(v->{individual=false; reset(); showScore();});
        solo.setOnClickListener(v->{individual=true; reset(); showScore();});
        root.addView(text("اللعب حالياً دون إنترنت. اللعب أونلاين سيضاف في مرحلة لاحقة.",14));
    }
    void reset(){ for(int i=0;i<4;i++) scores[i]=0; }
    void showScore() {
        shell(individual?"اللعب الفردي":"اللعب فريقين");
        root.addView(text("الهدف: "+target+" نقطة",16));
        String[] names=individual?new String[]{"اللاعب 1","اللاعب 2","اللاعب 3","اللاعب 4"}:
            new String[]{"الفريق 1","الفريق 2"};
        for(int i=0;i<names.length;i++){
            final int idx=i;
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER);
            TextView label=text(names[i]+": "+scores[i],18);
            Button add=btn("+10"); Button sub=btn("-10");
            add.setOnClickListener(v->{scores[idx]+=10; showScore();});
            sub.setOnClickListener(v->{scores[idx]-=10; showScore();});
            row.addView(label,new LinearLayout.LayoutParams(0,-2,1));
            row.addView(add); row.addView(sub); root.addView(row);
        }
        status=text("",18);
        int count=individual?4:2;
        for(int i=0;i<count;i++) if(scores[i]>=target) status.setText(names[i]+" فاز!");
        root.addView(status);
        Button back=btn("رجوع"); back.setOnClickListener(v->showHome()); root.addView(back);
        root.addView(text("تنبيه: تسجيل النقاط تجريبي؛ قواعد التوزيع والشراء واللعب لم تكتمل بعد.",13));
    }
}
